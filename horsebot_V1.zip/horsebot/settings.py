# BOT SETTINGS

TEST_MODE = True # if True, create bets but DO NOT place them
exit_on_error = True # set False to run 24/7 (i.e. bot has no coding errors)

# account info
username = 'xxxxxxxx'
password = 'xxxxxxxx'
app_key =  'xxxxxxxx' # your 'LIVE' app key

# betting
min_price = 1.30
max_price = 2.00
stake = 2.00

# market filters
preload_time = 30 # time in seconds. preload markets starting in next 'N' seconds
sport_ids = [7] # 7 = horse racing
countries = ['GB', 'IE'] # UK & Irish racing only
market_types = ['WIN'] # win only markets

